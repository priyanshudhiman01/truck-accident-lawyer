export interface Location {
  lat: number;
  lng: number;
}

export interface Lawyer {
  id: string;
  name: string;
  imageUrl: string;
  location: {
    address: string;
    city: string;
    state: string;
    coords: Location;
  };
  specializations: string[];
  rating: number;
  totalRatings: number;
  contact: {
    phone: string;
    email?: string;
    website?: string;
  };
  placeId: string;
  photos: string[];
  openingHours?: string[];
}

export interface SearchFilters {
  specialization: string[];
  rating: number;
  sortBy: 'rating' | 'distance';
}

export interface MapBounds {
  ne: Location;
  sw: Location;
}