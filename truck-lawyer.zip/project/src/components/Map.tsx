import React, { useEffect, useRef } from 'react';
import type { Lawyer, Location } from '../types';
import { googleMapsLoader } from '../services/GoogleMapsLoader';

interface MapProps {
  lawyers: Lawyer[];
  onBoundsChanged: (ne: Location, sw: Location) => void;
  selectedLawyer?: Lawyer;
}

export function Map({ lawyers, onBoundsChanged, selectedLawyer }: MapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const googleMapRef = useRef<google.maps.Map>();
  const markersRef = useRef<google.maps.Marker[]>([]);

  useEffect(() => {
    const initMap = async () => {
      await googleMapsLoader.load();
      
      if (mapRef.current && !googleMapRef.current) {
        googleMapRef.current = new google.maps.Map(mapRef.current, {
          center: { lat: 39.8283, lng: -98.5795 },
          zoom: 4,
          styles: [
            {
              featureType: 'all',
              elementType: 'labels.text.fill',
              stylers: [{ color: '#4a5568' }]
            },
            {
              featureType: 'water',
              elementType: 'geometry',
              stylers: [{ color: '#edf2f7' }]
            }
          ]
        });

        googleMapRef.current.addListener('bounds_changed', () => {
          const bounds = googleMapRef.current?.getBounds();
          if (bounds) {
            const ne = bounds.getNorthEast();
            const sw = bounds.getSouthWest();
            onBoundsChanged(
              { lat: ne.lat(), lng: ne.lng() },
              { lat: sw.lat(), lng: sw.lng() }
            );
          }
        });
      }
    };

    initMap();
  }, [onBoundsChanged]);

  useEffect(() => {
    if (googleMapRef.current) {
      // Clear existing markers
      markersRef.current.forEach(marker => marker.setMap(null));
      markersRef.current = [];

      // Add new markers
      lawyers.forEach(lawyer => {
        const marker = new google.maps.Marker({
          position: lawyer.location.coords,
          map: googleMapRef.current,
          title: lawyer.name,
          animation: selectedLawyer?.id === lawyer.id ? 
            google.maps.Animation.BOUNCE : undefined
        });

        markersRef.current.push(marker);
      });
    }
  }, [lawyers, selectedLawyer]);

  return (
    <div ref={mapRef} className="w-full h-[400px] rounded-lg shadow-md" />
  );
}