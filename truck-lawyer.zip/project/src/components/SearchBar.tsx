import React, { useState } from 'react';
import { Search } from 'lucide-react';

interface SearchBarProps {
  onSearch: (query: string) => void;
}

export function SearchBar({ onSearch }: SearchBarProps) {
  const [query, setQuery] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(query);
    
    // Smooth scroll to results
    const resultsSection = document.getElementById('results-section');
    if (resultsSection) {
      resultsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="relative w-full max-w-3xl mx-auto">
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search by location, lawyer, or firm name..."
        className="w-full px-8 py-6 text-xl text-gray-700 bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
      />
      <button
        type="submit"
        className="absolute right-4 top-1/2 -translate-y-1/2 bg-blue-600 text-white p-4 rounded-xl hover:bg-blue-700 transition-colors shadow-lg group"
      >
        <Search className="h-6 w-6 group-hover:scale-110 transition-transform" />
      </button>
    </form>
  );
}