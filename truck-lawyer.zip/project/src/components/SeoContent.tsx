import React from 'react';
import { Truck, Scale, Phone, Clock } from 'lucide-react';

export function SeoContent() {
  return (
    <article className="max-w-7xl mx-auto px-4 py-16 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl font-bold text-gray-900 mb-8">
          Expert Truck Accident Lawyers: Your Guide to Legal Representation
        </h2>

        {/* Key Benefits Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center mb-4">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Scale className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="ml-3 text-lg font-semibold">Legal Expertise</h3>
            </div>
            <p className="text-gray-600">
              Our network of specialized attorneys brings years of experience in handling complex truck accident cases.
            </p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center mb-4">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Clock className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="ml-3 text-lg font-semibold">24/7 Support</h3>
            </div>
            <p className="text-gray-600">
              Access to immediate legal consultation when you need it most, with attorneys ready to take your case.
            </p>
          </div>
        </div>

        {/* Main Content */}
        <div className="prose prose-lg max-w-none">
          <h3>Understanding Truck Accident Cases</h3>
          <p>
            Truck accidents can be devastating, often resulting in severe injuries and complex legal challenges. These cases differ significantly from regular car accidents due to multiple potentially liable parties, including trucking companies, manufacturers, and contractors. Our specialized attorneys understand the intricacies of federal trucking regulations and how they impact your case.
          </p>

          <div className="my-8">
            <img
              src="https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&q=80&w=2070"
              alt="Truck accident scene"
              className="w-full h-64 object-cover rounded-xl"
            />
          </div>

          <h3>Why You Need a Specialized Truck Accident Lawyer</h3>
          <p>
            Truck accident cases require specific expertise due to their complexity. A specialized attorney will:
          </p>
          <ul>
            <li>Understand federal and state trucking regulations</li>
            <li>Have experience with commercial insurance policies</li>
            <li>Know how to preserve and analyze critical evidence</li>
            <li>Be familiar with industry standards and practices</li>
          </ul>

          <h3>Time is Critical in Truck Accident Cases</h3>
          <p>
            Acting quickly after a truck accident is crucial. Evidence can disappear, witnesses' memories fade, and important data from the truck's black box can be overwritten. Our network of attorneys can immediately begin:
          </p>
          <ul>
            <li>Collecting and preserving evidence</li>
            <li>Interviewing witnesses</li>
            <li>Analyzing accident reports</li>
            <li>Consulting with accident reconstruction experts</li>
          </ul>

          <div className="my-8 bg-blue-50 p-6 rounded-xl">
            <h4 className="text-xl font-semibold text-blue-900 mb-4">
              Common Types of Truck Accident Claims
            </h4>
            <ul className="space-y-2">
              <li>Jackknife accidents</li>
              <li>Rollover accidents</li>
              <li>Rear-end collisions</li>
              <li>Underride accidents</li>
              <li>Wide turn accidents</li>
              <li>Blind spot accidents</li>
            </ul>
          </div>

          <h3>Maximizing Your Compensation</h3>
          <p>
            An experienced truck accident lawyer will help ensure you receive compensation for:
          </p>
          <ul>
            <li>Medical expenses (current and future)</li>
            <li>Lost wages and earning capacity</li>
            <li>Pain and suffering</li>
            <li>Property damage</li>
            <li>Rehabilitation costs</li>
          </ul>

          <div className="my-8">
            <img
              src="https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&q=80&w=2070"
              alt="Legal consultation"
              className="w-full h-64 object-cover rounded-xl"
            />
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-8 text-white text-center">
          <h3 className="text-2xl font-bold mb-4">
            Don't Wait to Get Legal Help
          </h3>
          <p className="mb-6">
            Our network of experienced truck accident lawyers is ready to help you get the compensation you deserve.
          </p>
          <div className="inline-flex items-center justify-center space-x-2 text-lg font-semibold">
            <Phone className="h-5 w-5" />
            <span>Start your search now</span>
          </div>
        </div>
      </div>
    </article>
  );
}